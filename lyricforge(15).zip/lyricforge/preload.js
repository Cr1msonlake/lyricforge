const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('lyricforge', {
  selectAudioFile: () => ipcRenderer.invoke('select-audio-file'),
  selectOutputPath: (defaultName) => ipcRenderer.invoke('select-output-path', defaultName),
  revealInFolder: (filePath) => ipcRenderer.invoke('reveal-in-folder', filePath),
  pexelsSearch: (params) => ipcRenderer.invoke('pexels-search', params),
  checkAndCacheClip: (url, clipId) => ipcRenderer.invoke('check-and-cache-clip', { url, clipId }),
  getPexelsKey: () => ipcRenderer.invoke('get-pexels-key'),
  setPexelsKey: (key) => ipcRenderer.invoke('set-pexels-key', key),
  renderVideo: (payload) => ipcRenderer.invoke('render-video', payload),
  getFontLibrary: () => ipcRenderer.invoke('get-font-library'),
  selectCustomFont: () => ipcRenderer.invoke('select-custom-font'),
  saveProject: (data) => ipcRenderer.invoke('save-project', data),
  loadProject: () => ipcRenderer.invoke('load-project'),
  onRenderProgress: (callback) => {
    const listener = (event, data) => callback(data);
    ipcRenderer.on('render-progress', listener);
    return () => ipcRenderer.removeListener('render-progress', listener);
  },
});
