# LyricForge (Desktop) — Beta

A native Windows desktop app (Electron) that recreates the LyricForge web prototype:
upload a song → paste lyrics → sync them word-by-word → pick Pexels stock clips → render an MP4 lyric video, entirely on your machine (no server).

## Features

- **Audio** — load MP3/WAV/M4A/AAC/OGG/FLAC from disk.
- **Lyrics** — paste any lyrics; auto-split into words, grouped by line.
- **Sync** — play the song and hit `Space` (or click **Mark word**) exactly when each word is sung.
  `←`/`→` seek 5s back/forward, `Backspace` undoes the last mark, `R` restarts.
- **Clips** — search Pexels stock video with your own API key (saved locally after you type it once — click **Clear** next to the key field to wipe it). Clicking a clip fully downloads and validates it before selecting it, and caches it. Each selected clip auto-picks a random 5–8s slice; a fill bar shows coverage, and every selected clip is listed with a thumbnail so you can always see what's in your background.
- **Save / Load project** — save your synced lyrics, clip selection, and all render settings to a `.lfproj` file, and pick up exactly where you left off later (top-right of the window).
- **Render options**:
  - **Title, subtitle & credits** — grouped together, each with its own optional show/hide timing. Credits are built from an "Add credit" list (Producer, Songwriter, Director, Featuring, or a custom label) rather than fixed fields, and can show during an extra "tail" appended after the song ends.
  - **Position** — drag the marker on the mini preview to place the title/subtitle/credits block anywhere on the frame. Snapping to a 3×3 grid (top-left, center, bottom-right, etc.) is on by default; toggle it off for freeform placement.
  - **Lyric mode** — Word by word, Line by line, Karaoke (dim full line + words light up and stay lit as they're sung), or Hybrid (same timing, no dim preview).
  - **Animation** — Cut (instant), Fade, or Slide in from any direction.
  - **Font** — 12+ built-in system fonts (including a "Brat"-style blurred lowercase preset) or your own uploaded `.ttf`/`.otf`, selectable right in the font dropdown. Custom font family names are read directly from the font file, not guessed from the filename.
  - **Details** — text size, side margins (long lines wrap within them), blur/softness, color, alignment (left/center/right/justified), vertical position, and an optional text outline with its own color.
- Renders entirely locally via a bundled FFmpeg binary — no cloud, no accounts. Footage via Pexels.

## Requirements

- [Node.js 18+](https://nodejs.org) (only needed to build/run from source — not needed to use an installed copy)
- Windows 10/11. Built-in fonts rely on the standard `C:\Windows\Fonts` files — use the font dropdown's "Custom font…" option if a particular one is missing on your system.
- A free [Pexels API key](https://www.pexels.com/api/) (used only for the Clips step)

## Run in development

```bash
cd lyricforge
npm install
npm start
```

## Build a Windows installer / portable exe

You're already running this app locally on your Windows machine, so building the installer is just as local — no GitHub or CI needed.

### Easiest: double-click `Build Installer.bat`

It installs anything missing, builds, and then collects just the finished installer (and a portable version) into a clean **`Release/`** folder at the project root — opening it for you automatically.

### Or manually, same result minus the tidy-up

```bash
cd lyricforge
npm install
npm run dist
```

This leaves the installer in `dist/` alongside a bunch of build-internal files (`win-unpacked/`, `.yaml` debug logs, `.blockmap`, etc.) that aren't meant to be shared — use the `.bat` if you want the clean, share-ready folder instead.

### Sharing it with other people

Just zip up the whole **`Release`** folder (or send `Release\LyricForge Setup 1.0.0.exe` directly) — that's the only file anyone else needs. No Node.js, no terminal, no project files required on their end; they just double-click the installer like any other program.

**Note on the Pexels API key:** it's saved to your own Windows user profile (`%APPDATA%\LyricForge\config.json`), not bundled into the installer — so sharing the `Release` folder never shares your key. Anyone who installs it gets a blank key field and needs to enter their own.

<details>
<summary>Optional: build automatically via GitHub Actions instead</summary>

This repo also includes `.github/workflows/build-windows.yml` if you'd ever rather have GitHub build it on a fresh machine for you (e.g. to build without Node.js installed locally). Push the project to a GitHub repo and check the **Actions** tab for the output. Not necessary for normal local use.
</details>

## How it works

- `main.js` — Electron main process: file dialogs, Pexels search proxying, and the FFmpeg render pipeline (`fluent-ffmpeg` + `ffmpeg-static`, so no external FFmpeg install is required).
- `preload.js` — a small, safe bridge (`contextIsolation: true`) exposing only the specific IPC calls the UI needs.
- `src/` — the UI: plain HTML/CSS/JS, five-step wizard (Audio → Lyrics → Sync → Clips → Render).

### Render pipeline details

1. Downloads your selected Pexels clips locally (in parallel).
2. Normalizes each to 1080p/30fps and trims to its randomized 5–8s slice (also in parallel).
3. Concatenates them into one background track and loops/trims it to match the song (plus any credits tail) exactly.
4. Builds a single **ASS subtitle track** (the same technology used by MKV/anime fansub karaoke) containing every title, subtitle, lyric, and credits cue with its exact timing, font, color, position, and animation — instead of hundreds of separate video filters.
5. Burns that one subtitle track onto the background video with FFmpeg's `subtitles` filter, then muxes in your original audio and exports the final MP4.

**Why the switch to ASS:** the previous version built one text filter per synced word directly on the FFmpeg command line. For a 3–5 minute song (hundreds of words) that command got long enough to hit Windows' command-line length limit, causing an `ENAMETOOLONG` crash — and having FFmpeg re-evaluate hundreds of chained filters on every video frame was also the main reason renders were slow. Moving lyric timing into a subtitle file removes both problems: the command line stays tiny regardless of song length, and libass (which is purpose-built for exactly this kind of many-cue, precisely-timed text) is far faster than a long drawtext chain. Clip downloading/processing now also runs in parallel instead of one-at-a-time, and the final encode uses a faster preset.

Karaoke and Hybrid modes use ASS's native `\k` karaoke tags, so already-sung words stay lit at their fixed position until the line changes, and word positions are laid out by real font metrics via libass rather than an estimated width.

## Notes / things you may want to tune

- Caption look (size, color, position) lives in `main.js` inside the `drawFilters` block — easy to restyle.
- Sync word timing is intentionally simple (tap-to-mark); each word's end time defaults to +0.4s or the next word's start, whichever is more accurate. You can rerun sync anytime before rendering.
- The Pexels key is kept in memory only (never written to disk) — re-enter it each session, or wire up `electron-store` if you'd like it remembered.
