@echo off
title LyricForge
cd /d "%~dp0"

echo Checking for Node.js...
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo.
    echo ============================================
    echo   Node.js is not installed or not found.
    echo   Download it from https://nodejs.org
    echo   (choose the LTS version), install it,
    echo   RESTART your laptop, then double-click
    echo   this file again.
    echo ============================================
    echo.
    pause
    exit /b
)

echo Node.js found.
echo.

if not exist "node_modules" (
    echo Setting up LyricForge for the first time...
    echo This only happens once and may take a few minutes.
    echo Please wait...
    echo.
    call npm install
    if %errorlevel% neq 0 (
        echo.
        echo ============================================
        echo   Setup failed. Scroll up to see the error
        echo   above this message.
        echo   Common fix: make sure you're connected to
        echo   the internet, then try again.
        echo ============================================
        echo.
        pause
        exit /b
    )
    echo.
    echo Setup complete.
    echo.
)

echo Launching LyricForge...
echo (Keep this window open while the app is running)
echo.
call npm start

echo.
echo ============================================
echo   LyricForge closed.
echo   If it closed immediately or you saw an error
echo   above, scroll up to read it.
echo ============================================
pause
