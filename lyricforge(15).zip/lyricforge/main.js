const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const https = require('https');
const { execFile } = require('child_process');
const ffmpegPath = require('ffmpeg-static').replace('app.asar', 'app.asar.unpacked');
const ffprobePath = require('ffprobe-static').path.replace('app.asar', 'app.asar.unpacked');
const ffmpeg = require('fluent-ffmpeg');

ffmpeg.setFfmpegPath(ffmpegPath);
ffmpeg.setFfprobePath(ffprobePath);

function logFatal(label, err) {
  try {
    const logDir = path.join(app.getPath('userData'), 'render-logs');
    fs.mkdirSync(logDir, { recursive: true });
    fs.appendFileSync(
      path.join(logDir, 'app-errors.log'),
      `[${new Date().toISOString()}] ${label}: ${err && err.stack ? err.stack : err}\n`
    );
  } catch (e) { /* best effort */ }
  console.error(label, err);
}
process.on('uncaughtException', (err) => logFatal('uncaughtException', err));
process.on('unhandledRejection', (err) => logFatal('unhandledRejection', err));

let mainWindow;
const customFontsDir = path.join(app.getPath('userData'), 'fonts');

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1360,
    height: 860,
    minWidth: 1100,
    minHeight: 720,
    backgroundColor: '#0b0b0f',
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });
  mainWindow.loadFile(path.join(__dirname, 'src', 'index.html'));
}

app.whenReady().then(async () => {
  if (!fs.existsSync(customFontsDir)) fs.mkdirSync(customFontsDir, { recursive: true });

  function checkBinary(binPath) {
    return new Promise((resolve) => {
      if (!fs.existsSync(binPath)) { resolve({ ok: false, reason: 'missing' }); return; }
      execFile(binPath, ['-version'], { timeout: 6000, windowsHide: true }, (err) => {
        resolve(err ? { ok: false, reason: 'broken' } : { ok: true });
      });
    });
  }

  const [ffmpegCheck, ffprobeCheck] = await Promise.all([checkBinary(ffmpegPath), checkBinary(ffprobePath)]);
  const problems = [];
  if (!ffmpegCheck.ok) problems.push(`FFmpeg (${ffmpegCheck.reason === 'missing' ? 'file not found' : "found, but won't run"}) at:\n${ffmpegPath}`);
  if (!ffprobeCheck.ok) problems.push(`FFprobe (${ffprobeCheck.reason === 'missing' ? 'file not found' : "found, but won't run"}) at:\n${ffprobePath}`);
  if (problems.length > 0) {
    dialog.showErrorBox(
      'LyricForge — a required component is broken',
      `${problems.join('\n\n')}\n\n` +
        `Most likely cause: your antivirus quarantined or altered this file in place.\n\n` +
        `To fix:\n1. Check your antivirus's quarantine/history and restore it if listed.\n` +
        `2. Add an exclusion for this whole project folder.\n` +
        `3. Delete "node_modules" and run "npm install" again.\n\n` +
        `The app will still open, but rendering won't work until this is fixed.`
    );
  }

  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});

app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });

// ---------- Fonts ----------

const FONT_LIBRARY = [
  { id: 'segoeui', label: 'Segoe UI (Default)', family: 'Segoe UI' },
  { id: 'arial', label: 'Arial', family: 'Arial' },
  { id: 'arialbd', label: 'Arial Bold', family: 'Arial' },
  { id: 'ariblk', label: 'Arial Black', family: 'Arial Black' },
  { id: 'arialn', label: 'Arial Narrow', family: 'Arial Narrow' },
  { id: 'brat', label: 'Brat (blurred lowercase)', family: 'Arial Narrow', forceLowercase: true },
  { id: 'times', label: 'Times New Roman', family: 'Times New Roman' },
  { id: 'georgia', label: 'Georgia', family: 'Georgia' },
  { id: 'verdana', label: 'Verdana', family: 'Verdana' },
  { id: 'trebuchet', label: 'Trebuchet MS', family: 'Trebuchet MS' },
  { id: 'comicsans', label: 'Comic Sans MS', family: 'Comic Sans MS' },
  { id: 'impact', label: 'Impact', family: 'Impact' },
  { id: 'courier', label: 'Courier New', family: 'Courier New' },
  { id: 'papyrus', label: 'Papyrus', family: 'Papyrus' },
];

ipcMain.handle('get-font-library', async () => {
  return FONT_LIBRARY.map((f) => ({ id: f.id, label: f.label, forceLowercase: !!f.forceLowercase }));
});

// Reads the real font family name out of a .ttf/.otf file's internal
// 'name' table, instead of guessing from the filename. This is what makes
// custom font upload actually work reliably — libass looks fonts up by
// their real family name, which very often does NOT match the filename.
function readFontFamilyName(buffer) {
  try {
    const numTables = buffer.readUInt16BE(4);
    let nameTableOffset = null;
    for (let i = 0; i < numTables; i++) {
      const recordOffset = 12 + i * 16;
      const tag = buffer.toString('ascii', recordOffset, recordOffset + 4);
      if (tag === 'name') {
        nameTableOffset = buffer.readUInt32BE(recordOffset + 8);
        break;
      }
    }
    if (nameTableOffset == null) return null;

    const format = buffer.readUInt16BE(nameTableOffset);
    const count = buffer.readUInt16BE(nameTableOffset + 2);
    const stringOffset = nameTableOffset + buffer.readUInt16BE(nameTableOffset + 4);

    let best = null;
    for (let i = 0; i < count; i++) {
      const recOffset = nameTableOffset + 6 + i * 12;
      const platformID = buffer.readUInt16BE(recOffset);
      const encodingID = buffer.readUInt16BE(recOffset + 2);
      const languageID = buffer.readUInt16BE(recOffset + 4);
      const nameID = buffer.readUInt16BE(recOffset + 6);
      const length = buffer.readUInt16BE(recOffset + 8);
      const offset = buffer.readUInt16BE(recOffset + 10);
      if (nameID !== 1 && nameID !== 16) continue; // Family / Typographic Family

      const raw = buffer.slice(stringOffset + offset, stringOffset + offset + length);
      let text;
      if (platformID === 3 || platformID === 0) {
        // Decode UTF-16BE (Windows/Unicode platform records use big-endian).
        let s = '';
        for (let j = 0; j + 1 < raw.length; j += 2) {
          s += String.fromCharCode(raw.readUInt16BE(j));
        }
        text = s;
      } else {
        text = raw.toString('latin1');
      }
      // Prefer nameID 16 (typographic family) and English language records.
      const score = (nameID === 16 ? 2 : 1) + (languageID === 0x409 || languageID === 0 ? 1 : 0);
      if (!best || score > best.score) best = { text, score };
    }
    return best ? best.text.trim() : null;
  } catch (e) {
    return null;
  }
}

ipcMain.handle('select-custom-font', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: 'Choose a font file',
    properties: ['openFile'],
    filters: [{ name: 'Fonts', extensions: ['ttf', 'otf'] }],
  });
  if (result.canceled || result.filePaths.length === 0) return null;
  const src = result.filePaths[0];
  const dest = path.join(customFontsDir, path.basename(src));
  fs.copyFileSync(src, dest);

  const buffer = fs.readFileSync(dest);
  const realFamily = readFontFamilyName(buffer);
  const fallbackLabel = path.basename(src, path.extname(src));

  return { path: dest, family: realFamily || fallbackLabel, label: realFamily || fallbackLabel };
});

// ---------- Local settings persistence ----------

const configPath = path.join(app.getPath('userData'), 'config.json');
function readConfig() {
  try { return JSON.parse(fs.readFileSync(configPath, 'utf8')); } catch (e) { return {}; }
}
function writeConfig(patch) {
  const merged = { ...readConfig(), ...patch };
  fs.writeFileSync(configPath, JSON.stringify(merged, null, 2), 'utf8');
  return merged;
}
ipcMain.handle('get-pexels-key', async () => readConfig().pexelsKey || '');
ipcMain.handle('set-pexels-key', async (event, key) => { writeConfig({ pexelsKey: key || '' }); return true; });

// ---------- Save / load projects ----------

ipcMain.handle('save-project', async (event, projectData) => {
  const result = await dialog.showSaveDialog(mainWindow, {
    title: 'Save LyricForge project',
    defaultPath: 'my-song.lfproj',
    filters: [{ name: 'LyricForge Project', extensions: ['lfproj'] }],
  });
  if (result.canceled || !result.filePath) return { saved: false };
  fs.writeFileSync(result.filePath, JSON.stringify(projectData, null, 2), 'utf8');
  return { saved: true, filePath: result.filePath };
});

ipcMain.handle('load-project', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: 'Open LyricForge project',
    properties: ['openFile'],
    filters: [{ name: 'LyricForge Project', extensions: ['lfproj'] }],
  });
  if (result.canceled || result.filePaths.length === 0) return null;
  try {
    const data = JSON.parse(fs.readFileSync(result.filePaths[0], 'utf8'));
    const audioExists = data.audioPath ? fs.existsSync(data.audioPath) : false;
    return { data, audioExists };
  } catch (e) {
    throw new Error('This file could not be read as a LyricForge project.');
  }
});

// ---------- File dialogs ----------

ipcMain.handle('select-audio-file', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: 'Choose a song',
    properties: ['openFile'],
    filters: [{ name: 'Audio', extensions: ['mp3', 'wav', 'm4a', 'aac', 'ogg', 'flac'] }],
  });
  if (result.canceled || result.filePaths.length === 0) return null;
  return { filePath: result.filePaths[0], fileName: path.basename(result.filePaths[0]) };
});

ipcMain.handle('select-output-path', async (event, defaultName) => {
  const result = await dialog.showSaveDialog(mainWindow, {
    title: 'Save your lyric video',
    defaultPath: defaultName || 'lyric-video.mp4',
    filters: [{ name: 'MP4 Video', extensions: ['mp4'] }],
  });
  if (result.canceled || !result.filePath) return null;
  return result.filePath;
});

ipcMain.handle('reveal-in-folder', async (event, filePath) => { shell.showItemInFolder(filePath); });

// ---------- Pexels search ----------

function httpsGetJson(url, headers) {
  return new Promise((resolve, reject) => {
    https.get(url, { headers }, (res) => {
      let data = '';
      res.on('data', (chunk) => (data += chunk));
      res.on('end', () => {
        if (res.statusCode < 200 || res.statusCode >= 300) {
          reject(new Error(`Pexels error ${res.statusCode}: ${data.slice(0, 200)}`));
          return;
        }
        try { resolve(JSON.parse(data)); } catch (e) { reject(e); }
      });
    }).on('error', reject);
  });
}

ipcMain.handle('pexels-search', async (event, { apiKey, query, perPage, page }) => {
  if (!apiKey) throw new Error('Missing Pexels API key.');
  const url = `https://api.pexels.com/videos/search?query=${encodeURIComponent(query)}&per_page=${perPage || 12}&page=${page || 1}&orientation=landscape`;
  const json = await httpsGetJson(url, { Authorization: apiKey });
  const clips = (json.videos || []).map((v) => {
    const files = (v.video_files || []).filter((f) => f.file_type === 'video/mp4');
    files.sort((a, b) => (b.width || 0) - (a.width || 0));
    const best = files.find((f) => f.width && f.width <= 1920) || files[0];
    return {
      id: v.id, duration: v.duration, thumbnail: v.image, width: v.width, height: v.height,
      downloadUrl: best ? best.link : null, user: v.user ? v.user.name : 'Pexels',
    };
  });
  const filtered = clips.filter((c) => c.downloadUrl);
  return { clips: filtered, page: json.page || page || 1, totalResults: json.total_results || 0, hasMore: !!json.next_page };
});

function downloadFile(url, destPath) {
  return new Promise((resolve, reject) => {
    const file = fs.createWriteStream(destPath);
    https.get(url, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        file.close();
        fs.unlink(destPath, () => { downloadFile(res.headers.location, destPath).then(resolve).catch(reject); });
        return;
      }
      if (res.statusCode < 200 || res.statusCode >= 300) {
        let body = '';
        res.on('data', (chunk) => { if (body.length < 300) body += chunk; });
        res.on('end', () => {
          file.close();
          fs.unlink(destPath, () => reject(new Error(`HTTP ${res.statusCode} downloading clip${body ? `: ${body.slice(0, 200)}` : ''}`)));
        });
        return;
      }
      res.pipe(file);
      file.on('finish', () => {
        file.close(() => {
          const stats = fs.statSync(destPath);
          if (stats.size < 20000) {
            fs.unlink(destPath, () => reject(new Error(`Downloaded file is suspiciously small (${stats.size} bytes).`)));
            return;
          }
          resolve(destPath);
        });
      });
    }).on('error', (err) => { fs.unlink(destPath, () => reject(err)); });
  });
}

async function downloadFileWithRetry(url, destPath, attempts = 3) {
  let lastErr;
  for (let i = 0; i < attempts; i++) {
    try { return await downloadFile(url, destPath); }
    catch (err) { lastErr = err; if (i < attempts - 1) await new Promise((r) => setTimeout(r, 800 * (i + 1))); }
  }
  throw lastErr;
}

function ffprobeDuration(filePath) {
  return new Promise((resolve, reject) => {
    ffmpeg.ffprobe(filePath, (err, data) => {
      if (err) return reject(err);
      resolve(data.format.duration || 0);
    });
  });
}

async function mapWithConcurrency(items, limit, fn) {
  const results = new Array(items.length);
  let nextIndex = 0;
  async function worker() {
    while (nextIndex < items.length) {
      const i = nextIndex++;
      results[i] = await fn(items[i], i);
    }
  }
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, worker));
  return results;
}

// ---------- Clip cache ----------

const clipCacheDir = path.join(app.getPath('userData'), 'clip-cache');
try { fs.rmSync(clipCacheDir, { recursive: true, force: true }); } catch (e) { /* best effort */ }
fs.mkdirSync(clipCacheDir, { recursive: true });
function clipCachePath(clipId) { return path.join(clipCacheDir, `clip_${clipId}.mp4`); }

let activeClipChecks = 0;
const clipCheckQueue = [];
const MAX_CONCURRENT_CLIP_CHECKS = 2;
function queueClipCheck(fn) {
  return new Promise((resolve, reject) => {
    const run = () => {
      activeClipChecks += 1;
      fn().then(resolve, reject).finally(() => {
        activeClipChecks -= 1;
        const next = clipCheckQueue.shift();
        if (next) next();
      });
    };
    if (activeClipChecks < MAX_CONCURRENT_CLIP_CHECKS) run(); else clipCheckQueue.push(run);
  });
}

ipcMain.handle('check-and-cache-clip', async (event, { url, clipId }) => {
  return queueClipCheck(async () => {
    const dest = clipCachePath(clipId);
    if (fs.existsSync(dest)) return { valid: true };
    try {
      await downloadFileWithRetry(url, dest, 3);
      await ffprobeDuration(dest);
      return { valid: true };
    } catch (err) {
      try { fs.unlinkSync(dest); } catch (e) { /* ignore */ }
      return { valid: false, error: err.message };
    }
  });
});

// ---------- Text / ASS helpers ----------

function assEscapeText(text) {
  return String(text).replace(/\{/g, '(').replace(/\}/g, ')').replace(/\n/g, '\\N');
}

function hexToAssColor(hex, opacityPercent) {
  const clean = String(hex || '#ffffff').replace('#', '');
  const r = clean.substring(0, 2) || 'ff';
  const g = clean.substring(2, 4) || 'ff';
  const b = clean.substring(4, 6) || 'ff';
  const op = opacityPercent == null ? 100 : opacityPercent;
  const alphaByte = Math.round((1 - op / 100) * 255);
  const aa = alphaByte.toString(16).padStart(2, '0').toUpperCase();
  return `&H${aa}${b.toUpperCase()}${g.toUpperCase()}${r.toUpperCase()}&`;
}

function secToAssTime(sec) {
  const s = Math.max(0, sec);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const ss = Math.floor(s % 60);
  const cs = Math.round((s - Math.floor(s)) * 100);
  return `${h}:${String(m).padStart(2, '0')}:${String(ss).padStart(2, '0')}.${String(cs).padStart(2, '0')}`;
}

function estimateTextWidth(text, fontSize) { return text.length * fontSize * 0.56; }

const ALIGN_MAP = {
  'left-top': 7, 'center-top': 8, 'right-top': 9,
  'left-middle': 4, 'center-middle': 5, 'right-middle': 6,
  'left-bottom': 1, 'center-bottom': 2, 'right-bottom': 3,
};

// 9-point preset -> {an, x, y} anchor for the Title/Subtitle/Credits block.
function resolvePositionAnchor(position, canvasW, canvasH) {
  const margin = 64;
  const presets = {
    'top-left': { an: 7, x: margin, y: margin },
    'top-center': { an: 8, x: canvasW / 2, y: margin },
    'top-right': { an: 9, x: canvasW - margin, y: margin },
    'middle-left': { an: 4, x: margin, y: canvasH / 2 },
    'center': { an: 5, x: canvasW / 2, y: canvasH / 2 },
    'middle-right': { an: 6, x: canvasW - margin, y: canvasH / 2 },
    'bottom-left': { an: 1, x: margin, y: canvasH - margin },
    'bottom-center': { an: 2, x: canvasW / 2, y: canvasH - margin },
    'bottom-right': { an: 3, x: canvasW - margin, y: canvasH - margin },
  };
  if (position && position.preset === 'custom') {
    return { an: 5, x: (position.customX / 100) * canvasW, y: (position.customY / 100) * canvasH };
  }
  return presets[(position && position.preset) || 'top-center'];
}

function buildAssHeader({ canvasW, canvasH, lyricStyle, titleStyle, subtitleStyle, creditsStyle }) {
  function styleLine(name, s) {
    return (
      `Style: ${name},${s.font},${s.size},${s.primary},${s.secondary},${s.outline},&H00000000,` +
      `0,0,0,0,100,100,0,0,1,${s.borderWidth},0,${s.alignment},${s.marginL},${s.marginR},${s.marginV},1`
    );
  }
  return [
    '[Script Info]', 'Title: LyricForge', 'ScriptType: v4.00+',
    `PlayResX: ${canvasW}`, `PlayResY: ${canvasH}`,
    'WrapStyle: 0', 'ScaledBorderAndShadow: yes', '',
    '[V4+ Styles]',
    'Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding',
    styleLine('Lyric', lyricStyle), styleLine('Title', titleStyle),
    styleLine('Subtitle', subtitleStyle), styleLine('Credits', creditsStyle),
    '', '[Events]',
    'Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text',
  ].join('\n');
}

function slideOffset(direction) {
  const d = 46;
  switch (direction) {
    case 'slideUp': return { dx: 0, dy: d };
    case 'slideDown': return { dx: 0, dy: -d };
    case 'slideLeft': return { dx: d, dy: 0 };
    case 'slideRight': return { dx: -d, dy: 0 };
    default: return null;
  }
}

// Builds enter animation tags for a text event. 'cut' = no tags at all
// (instant hard cut). Exit is always a short, reliable fade — arbitrary
// independent enter+exit position animation isn't reliably supported by
// the subtitle format we render through, so we deliberately keep exit
// simple rather than risk broken-looking output.
function animTags(enterType, x, y) {
  if (enterType === 'cut') return '';
  const slide = slideOffset(enterType);
  if (slide) {
    const x0 = Math.round(x + slide.dx);
    const y0 = Math.round(y + slide.dy);
    return `\\move(${x0},${y0},${Math.round(x)},${Math.round(y)},0,180)\\fad(120,180)`;
  }
  return `\\fad(180,180)`;
}

// Word/Line-mode text: uses \move for slide-in, which REPLACES normal
// wrapping-capable positioning — fine for single short words, but for
// longer lines this must fall back to plain \fad so long text can still
// wrap within the configured side margins instead of running off-screen.
function buildLyricDrawtextEvents(opts) {
  const { words, lines, mode, animation, canvasW, canvasH, align, vpos, fontSize, marginX } = opts;
  const events = [];
  const alignKey = `${align === 'justify' ? 'left' : align}-${vpos}`;
  const assAlign = ALIGN_MAP[alignKey] || 2;

  function restingY() {
    if (vpos === 'top') return canvasH * 0.14;
    if (vpos === 'middle') return canvasH * 0.5;
    return canvasH - 140;
  }

  function pushSimple(text, start, end, allowMove) {
    if (start == null || end == null || end <= start) return;
    const safe = assEscapeText(text);
    let tags;
    if (allowMove) {
      const width = estimateTextWidth(safe, fontSize);
      let x;
      if (align === 'left' || align === 'justify') x = marginX + width / 2;
      else if (align === 'right') x = canvasW - marginX - width / 2;
      else x = canvasW / 2;
      tags = animTags(animation.enter, x, restingY());
    } else {
      // Long text: skip \move (which would break wrapping) and use fade only.
      tags = animation.enter === 'cut' ? '' : '\\fad(180,180)';
    }
    events.push(`Dialogue: 0,${secToAssTime(start)},${secToAssTime(end)},Lyric,,0,0,0,,{${tags}}${safe}`);
  }

  if (mode === 'word') {
    words.forEach((w) => pushSimple(w.text, w.start, w.end, true));
  } else if (mode === 'line') {
    lines.forEach((line) => {
      const lineWords = line.words.filter((w) => w.start != null && w.end != null);
      if (lineWords.length === 0) return;
      const allowMove = line.text.length * fontSize * 0.56 < canvasW * 0.5;
      pushSimple(line.text, lineWords[0].start, lineWords[lineWords.length - 1].end, allowMove);
    });
  } else if (mode === 'karaoke' || mode === 'hybrid') {
    lines.forEach((line) => {
      const lineWords = line.words.filter((w) => w.start != null && w.end != null);
      if (lineWords.length === 0) return;
      const lineStart = lineWords[0].start;
      const lineEnd = lineWords[lineWords.length - 1].end;
      let text = '';
      lineWords.forEach((w, i) => {
        const nextStart = i < lineWords.length - 1 ? lineWords[i + 1].start : lineEnd;
        const kCentiseconds = Math.max(1, Math.round((nextStart - w.start) * 100));
        text += `{\\k${kCentiseconds}}${assEscapeText(w.text)} `;
      });
      events.push(`Dialogue: 0,${secToAssTime(lineStart)},${secToAssTime(lineEnd)},Lyric,,0,0,0,karaoke,${text.trim()}`);
    });
  }

  return { events, assAlign };
}

// ---------- Render pipeline ----------

ipcMain.handle('render-video', async (event, payload) => {
  const {
    audioPath, words, lines, clips, outputPath,
    title, subtitle, credits, position,
    lyricMode, animation, font, details,
  } = payload;

  const sender = event.sender;
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'lyricforge-'));
  const report = (pct, msg) => sender.send('render-progress', { pct, msg });

  try {
    report(2, 'Preparing…');
    const audioDuration = await ffprobeDuration(audioPath);
    const tailSeconds = credits && credits.show && credits.tailSeconds ? Number(credits.tailSeconds) : 0;
    const totalDuration = audioDuration + tailSeconds;

    const skippedClips = [];
    const logDir = path.join(app.getPath('userData'), 'render-logs');
    fs.mkdirSync(logDir, { recursive: true });
    function logSkippedClip(label, detail) {
      skippedClips.push(label);
      try { fs.appendFileSync(path.join(logDir, 'skipped-clips.log'), `[${new Date().toISOString()}] ${label}: ${detail}\n`); }
      catch (e) { /* best effort */ }
    }

    report(4, `Downloading ${clips.length} clip(s)…`);
    const localClipsRaw = await mapWithConcurrency(clips, 3, async (c, i) => {
      const dest = path.join(tmpDir, `clip_${i}.mp4`);
      try {
        const cached = clipCachePath(c.id);
        if (fs.existsSync(cached)) fs.copyFileSync(cached, dest);
        else await downloadFileWithRetry(c.downloadUrl, dest);
        await ffprobeDuration(dest);
      } catch (err) {
        logSkippedClip(`clip ${i + 1}/${clips.length} (download)`, err.message);
        report(4 + Math.round(((i + 1) / clips.length) * 14), `Skipped a bad clip (${i + 1}/${clips.length})`);
        return null;
      }
      report(4 + Math.round(((i + 1) / clips.length) * 14), `Downloaded clip ${i + 1}/${clips.length}`);
      return { path: dest, trimStart: c.trimStart || 0, trimDuration: c.trimDuration || 6 };
    });
    const localClips = localClipsRaw.filter(Boolean);
    if (localClips.length === 0) {
      throw new Error(`None of the selected clips could be downloaded successfully. Try picking different clips. Details: ${path.join(logDir, 'skipped-clips.log')}`);
    }

    report(20, 'Preparing background footage…');
    const normalizedDir = path.join(tmpDir, 'norm');
    fs.mkdirSync(normalizedDir);
    let normalizedDone = 0;
    const normalizedPathsRaw = await mapWithConcurrency(localClips, Math.max(2, os.cpus().length - 1), async (c, i) => {
      const outPath = path.join(normalizedDir, `n_${i}.mp4`);
      try {
        await new Promise((resolve, reject) => {
          let stderrFull = '';
          ffmpeg(c.path)
            .inputOptions(['-ss', String(c.trimStart)])
            .outputOptions(['-t', String(c.trimDuration), '-vf', 'scale=1920:1080:force_original_aspect_ratio=increase,crop=1920:1080,fps=30', '-an'])
            .output(outPath)
            .on('stderr', (line) => { stderrFull += line + '\n'; })
            .on('end', resolve)
            .on('error', (err) => reject(new Error(`${err.message}\n${stderrFull.slice(-600)}`)))
            .run();
        });
      } catch (err) {
        logSkippedClip(`clip ${i + 1} (normalize)`, err.message);
        normalizedDone += 1;
        report(20 + Math.round((normalizedDone / localClips.length) * 20), `Skipped a bad clip (${normalizedDone}/${localClips.length})`);
        return null;
      }
      normalizedDone += 1;
      report(20 + Math.round((normalizedDone / localClips.length) * 20), `Processed clip ${normalizedDone}/${localClips.length}`);
      return outPath;
    });
    const normalizedPathsUnordered = normalizedPathsRaw.filter(Boolean);
    if (normalizedPathsUnordered.length === 0) {
      throw new Error(`None of the downloaded clips could be processed. Try picking different clips. Details: ${path.join(logDir, 'skipped-clips.log')}`);
    }

    const concatListPath = path.join(tmpDir, 'concat.txt');
    fs.writeFileSync(concatListPath, normalizedPathsUnordered.map((p) => `file '${p.replace(/'/g, "'\\''")}'`).join('\n'));
    const backgroundPath = path.join(tmpDir, 'background.mp4');
    report(42, 'Stitching background…');
    await new Promise((resolve, reject) => {
      ffmpeg().input(concatListPath).inputOptions(['-f', 'concat', '-safe', '0'])
        .outputOptions(['-c', 'copy']).output(backgroundPath)
        .on('end', resolve).on('error', (err) => reject(new Error(`[stitching background] ${err.message}`))).run();
    });

    const bgMatchedPath = path.join(tmpDir, 'background_matched.mp4');
    report(48, 'Matching video length…');
    await new Promise((resolve, reject) => {
      ffmpeg(backgroundPath).inputOptions(['-stream_loop', '-1'])
        .outputOptions(['-fflags', '+genpts', '-t', String(totalDuration), '-c:v', 'libx264', '-preset', 'veryfast', '-pix_fmt', 'yuv420p'])
        .output(bgMatchedPath).on('end', resolve)
        .on('error', (err) => reject(new Error(`[matching video length] ${err.message}`))).run();
    });

    report(54, 'Laying out text…');
    const fontFamily = font && font.customFamily ? font.customFamily : (FONT_LIBRARY.find((f) => f.id === (font && font.libraryId)) || FONT_LIBRARY[0]).family;
    const forceLowercase = font && font.forceLowercase;
    const fontSize = (details && details.fontSize) || 90;
    const colorHex = (details && details.color) || '#ffcc00';
    const align = (details && details.align) || 'center';
    const marginX = (details && details.marginX) != null ? details.marginX : 80;
    const vpos = (details && details.vposition) || 'bottom';
    const blur = (details && details.blur) || 0;
    const border = !!(details && details.border);
    const borderColorHex = (details && details.borderColor) || '#000000';
    const CANVAS_W = 1920, CANVAS_H = 1080;

    const primaryColor = hexToAssColor(colorHex, 100);
    const dimColor = hexToAssColor(colorHex, 35);
    const invisible = '&HFF000000&';
    const outlineColor = hexToAssColor(borderColorHex, 100);

    const { events: lyricEvents, assAlign } = buildLyricDrawtextEvents({
      words: forceLowercase ? words.map((w) => ({ ...w, text: w.text.toLowerCase() })) : words,
      lines: forceLowercase
        ? lines.map((l) => ({ text: l.text.toLowerCase(), words: l.words.map((w) => ({ ...w, text: w.text.toLowerCase() })) }))
        : lines,
      mode: lyricMode || 'word', animation: animation || { enter: 'fade' },
      canvasW: CANVAS_W, canvasH: CANVAS_H, align, vpos, fontSize, marginX,
    });

    const lyricStyle = {
      font: fontFamily, size: fontSize, primary: primaryColor,
      secondary: lyricMode === 'karaoke' ? dimColor : invisible,
      outline: outlineColor, borderWidth: border ? 3 : 0,
      alignment: assAlign, marginL: marginX, marginR: marginX,
      marginV: vpos === 'top' ? Math.round(CANVAS_H * 0.14) : vpos === 'middle' ? 0 : 140,
    };
    const titleStyle = { font: fontFamily, size: Math.round(fontSize * 1.15), primary: primaryColor, secondary: primaryColor, outline: outlineColor, borderWidth: border ? 4 : 0, alignment: 5, marginL: 40, marginR: 40, marginV: 0 };
    const subtitleStyle = { font: fontFamily, size: Math.round(fontSize * 0.5), primary: '&H00FFFFFF&', secondary: '&H00FFFFFF&', outline: outlineColor, borderWidth: border ? 3 : 0, alignment: 5, marginL: 40, marginR: 40, marginV: 0 };
    const creditsStyle = { font: fontFamily, size: Math.round(fontSize * 0.42), primary: '&H1AFFFFFF&', secondary: '&H1AFFFFFF&', outline: outlineColor, borderWidth: border ? 2 : 0, alignment: 5, marginL: 40, marginR: 40, marginV: 0 };

    const assParts = [buildAssHeader({ canvasW: CANVAS_W, canvasH: CANVAS_H, lyricStyle, titleStyle, subtitleStyle, creditsStyle })];
    assParts.push(...lyricEvents);

    const anchor = resolvePositionAnchor(position, CANVAS_W, CANVAS_H);
    let stackOffset = 0;

    if (title && title.show && title.text) {
      const tStart = title.startTime != null ? title.startTime : 0;
      const tEnd = title.endTime != null ? title.endTime : 4;
      const y = anchor.y + stackOffset;
      assParts.push(`Dialogue: 0,${secToAssTime(tStart)},${secToAssTime(tEnd)},Title,,0,0,0,,{\\an${anchor.an}\\pos(${Math.round(anchor.x)},${Math.round(y)})\\fad(200,200)}${assEscapeText(title.text)}`);
      stackOffset += Math.round(fontSize * 1.15 * 1.3);
    }

    if (subtitle && subtitle.show && subtitle.text) {
      const sStart = subtitle.startTime != null ? subtitle.startTime : 0;
      const sEnd = subtitle.endTime != null ? subtitle.endTime : 4;
      const y = anchor.y + stackOffset;
      assParts.push(`Dialogue: 0,${secToAssTime(sStart)},${secToAssTime(sEnd)},Subtitle,,0,0,0,,{\\an${anchor.an}\\pos(${Math.round(anchor.x)},${Math.round(y)})\\fad(200,200)}${assEscapeText(subtitle.text)}`);
    }

    if (credits && credits.show && Array.isArray(credits.items) && credits.items.length > 0) {
      const creditText = assEscapeText(credits.items.map((c) => `${c.type}: ${c.value}`).join('   \u2022   '));
      let cStart = credits.startTime != null ? credits.startTime : Math.max(0, audioDuration - 5);
      let cEnd = credits.endTime != null ? credits.endTime : totalDuration;
      cStart = Math.max(0, Math.min(cStart, totalDuration - 0.1));
      cEnd = Math.max(cStart + 0.1, Math.min(cEnd, totalDuration));
      assParts.push(`Dialogue: 0,${secToAssTime(cStart)},${secToAssTime(cEnd)},Credits,,0,0,0,,{\\an${anchor.an}\\pos(${Math.round(anchor.x)},${Math.round(anchor.y)})\\fad(200,200)}${creditText}`);
    }

    const assPath = path.join(tmpDir, 'lyrics.ass');
    fs.writeFileSync(assPath, assParts.join('\n'), 'utf8');

    const localFontsDir = path.join(tmpDir, 'fonts');
    fs.mkdirSync(localFontsDir, { recursive: true });
    if (fs.existsSync(customFontsDir)) {
      for (const f of fs.readdirSync(customFontsDir)) fs.copyFileSync(path.join(customFontsDir, f), path.join(localFontsDir, f));
    }

    report(60, 'Rendering final video… this can take a while');
    const prevCwd = process.cwd();
    process.chdir(tmpDir);

    let videoChain;
    if (blur > 0) {
      videoChain = `[0:v]subtitles=filename='lyrics.ass':fontsdir='fonts'[withtext];[withtext]gblur=sigma=${blur}:steps=1[outv]`;
    } else {
      videoChain = `[0:v]subtitles=filename='lyrics.ass':fontsdir='fonts'[outv]`;
    }

    try {
      await new Promise((resolve, reject) => {
        const cmd = ffmpeg(bgMatchedPath).input(audioPath);
        const audioFilter = tailSeconds > 0 ? ['-af', `apad=pad_dur=${tailSeconds}`] : [];
        let stderrFull = '';
        cmd.complexFilter(videoChain)
          .outputOptions([
            '-map', '[outv]', '-map', '1:a', ...audioFilter,
            '-t', String(totalDuration), '-c:v', 'libx264', '-preset', 'faster', '-crf', '21',
            '-c:a', 'aac', '-b:a', '192k', '-pix_fmt', 'yuv420p', '-max_muxing_queue_size', '9999',
          ])
          .output(outputPath)
          .on('stderr', (line) => { stderrFull += line + '\n'; })
          .on('progress', (p) => { if (p.percent) report(60 + Math.min(38, Math.round((p.percent / 100) * 38)), `Rendering… ${Math.round(p.percent)}%`); })
          .on('end', resolve)
          .on('error', (err) => {
            const logPath = path.join(logDir, 'last-render-error.log');
            try { fs.writeFileSync(logPath, stderrFull, 'utf8'); } catch (e) { /* best effort */ }
            reject(new Error(`${err.message}\n${stderrFull.slice(-800)}\n\nFull log saved to: ${logPath}`));
          })
          .run();
      });
    } finally {
      process.chdir(prevCwd);
    }

    report(100, 'Done!');
    return { success: true, outputPath, skippedClips: skippedClips.length };
  } finally {
    fs.rm(tmpDir, { recursive: true, force: true }, () => {});
  }
});
