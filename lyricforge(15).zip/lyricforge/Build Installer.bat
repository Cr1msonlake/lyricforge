@echo off
title LyricForge - Build Installer
cd /d "%~dp0"

echo Checking for Node.js...
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo.
    echo Node.js is not installed. Get it from https://nodejs.org
    echo then run this again.
    echo.
    pause
    exit /b
)

if not exist "node_modules" (
    echo Installing dependencies for the first time, please wait...
    call npm install
    if %errorlevel% neq 0 (
        echo.
        echo Setup failed - scroll up to see the error above.
        pause
        exit /b
    )
)

echo.
echo Building your Windows installer...
echo This can take a few minutes the first time.
echo.
set CSC_IDENTITY_AUTO_DISCOVERY=false
call npm run dist

if %errorlevel% neq 0 (
    echo.
    echo ============================================
    echo   Build failed - scroll up to see the error.
    echo ============================================
    pause
    exit /b
)

echo.
echo Collecting the finished installer into a clean folder...

if exist "Release" rmdir /s /q "Release"
mkdir "Release"

for %%F in ("dist\*Setup*.exe") do copy "%%F" "Release\" >nul
for %%F in ("dist\LyricForge*.exe") do (
    echo %%~nF | findstr /i "Setup" >nul
    if errorlevel 1 copy "%%F" "Release\LyricForge-Portable.exe" >nul
)

echo.
echo ============================================
echo   Done! Opening the Release folder.
echo   This folder contains ONLY what you need to
echo   share with other people - just send them
echo   the whole "Release" folder (or zip it).
echo ============================================
echo.
start "" "Release"
pause
