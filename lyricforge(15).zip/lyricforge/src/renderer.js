// ---------- App state ----------
const state = {
  step: 'audio',
  audioPath: null,
  audioFileName: null,
  audioDuration: 0,
  words: [],
  lines: [],
  syncIndex: 0,
  clips: [],
  selectedClips: [],
  fontLibrary: [],
  customFont: null, // { path, family, label }
  creditItems: [],
  position: { xPercent: 50, yPercent: 14, snap: true },
};

const STEP_ORDER = ['audio', 'lyrics', 'sync', 'clips', 'render'];
const CREDIT_TYPES = ['Producer', 'Songwriter', 'Director', 'Mixed by', 'Mastered by', 'Featuring', 'Vocals', 'Custom label'];

function goToStep(step) {
  state.step = step;
  document.querySelectorAll('.panel').forEach((p) => p.classList.remove('active'));
  document.getElementById(`panel-${step}`).classList.add('active');
  document.querySelectorAll('.step').forEach((btn) => {
    const s = btn.dataset.step;
    btn.classList.toggle('active', s === step);
    btn.classList.toggle('done', STEP_ORDER.indexOf(s) < STEP_ORDER.indexOf(step));
  });
  if (step === 'render') renderSummary();
}

document.querySelectorAll('[data-back]').forEach((btn) => {
  btn.addEventListener('click', () => goToStep(btn.dataset.back));
});

// ---------- Topbar: Pexels key, Save/Load project ----------

const pexelsKeyInput = document.getElementById('pexelsKey');
const clearPexelsKeyBtn = document.getElementById('clearPexelsKeyBtn');

window.lyricforge.getPexelsKey().then((savedKey) => { if (savedKey) pexelsKeyInput.value = savedKey; });

let pexelsKeySaveTimer = null;
pexelsKeyInput.addEventListener('input', () => {
  clearTimeout(pexelsKeySaveTimer);
  pexelsKeySaveTimer = setTimeout(() => window.lyricforge.setPexelsKey(pexelsKeyInput.value.trim()), 500);
});
clearPexelsKeyBtn.addEventListener('click', () => {
  pexelsKeyInput.value = '';
  window.lyricforge.setPexelsKey('');
});

const saveProjectBtn = document.getElementById('saveProjectBtn');
const loadProjectBtn = document.getElementById('loadProjectBtn');

function gatherProjectSnapshot() {
  return {
    audioPath: state.audioPath,
    audioFileName: state.audioFileName,
    audioDuration: state.audioDuration,
    lines: state.lines,
    words: state.words,
    selectedClips: state.selectedClips,
    creditItems: state.creditItems,
    position: state.position,
    lyricMode: selectedLyricMode,
    fontSelectValue: fontSelect.value,
    customFont: state.customFont,
    render: {
      titleShow: document.getElementById('titleShow').checked,
      titleText: document.getElementById('titleText').value,
      titleStart: document.getElementById('titleStart').value,
      titleEnd: document.getElementById('titleEnd').value,
      subtitleShow: document.getElementById('subtitleShow').checked,
      subtitleText: document.getElementById('subtitleText').value,
      subtitleStart: document.getElementById('subtitleStart').value,
      subtitleEnd: document.getElementById('subtitleEnd').value,
      creditsShow: document.getElementById('creditsShow').checked,
      creditsStart: document.getElementById('creditsStart').value,
      creditsEnd: document.getElementById('creditsEnd').value,
      creditsTail: document.getElementById('creditsTail').value,
      animEnter: document.getElementById('animEnter').value,
      detFontSize: document.getElementById('detFontSize').value,
      detMarginX: document.getElementById('detMarginX').value,
      detBlur: document.getElementById('detBlur').value,
      detColor: document.getElementById('detColor').value,
      detAlign: document.getElementById('detAlign').value,
      detVPos: document.getElementById('detVPos').value,
      detBorder: document.getElementById('detBorder').checked,
      detBorderColor: document.getElementById('detBorderColor').value,
    },
  };
}

function restoreProjectSnapshot(snap, audioExists) {
  if (audioExists && snap.audioPath) {
    state.audioPath = snap.audioPath;
    state.audioFileName = snap.audioFileName;
    audioLabel.textContent = 'Selected:';
    audioFileName.textContent = snap.audioFileName || '';
    audioPlayer.src = `file://${snap.audioPath}`;
    audioPlayer.style.display = 'block';
    toLyricsBtn.disabled = false;
  }
  state.audioDuration = snap.audioDuration || 0;
  state.lines = snap.lines || [];
  state.words = snap.words || [];
  state.syncIndex = state.words.findIndex((w) => w.start == null);
  if (state.syncIndex === -1) state.syncIndex = state.words.length;
  lyricsInput.value = state.lines.map((l) => l.text).join('\n');
  toSyncBtn.disabled = state.lines.length === 0;
  buildSyncLine();

  state.selectedClips = snap.selectedClips || [];
  renderSelectedClipList();
  updateFillBar();
  toRenderBtn.disabled = state.selectedClips.length === 0;

  state.creditItems = snap.creditItems || [];
  renderCreditList();
  state.position = snap.position || { xPercent: 50, yPercent: 14, snap: true };
  updateMarkerPosition();
  updateSnapButtonLabel();

  selectedLyricMode = snap.lyricMode || 'word';
  lyricModeSeg.querySelectorAll('.seg-btn').forEach((b) => b.classList.toggle('active', b.dataset.value === selectedLyricMode));

  state.customFont = snap.customFont || null;
  if (snap.fontSelectValue) {
    ensureFontOptionExists(snap.fontSelectValue, state.customFont);
    fontSelect.value = snap.fontSelectValue;
  }

  const r = snap.render || {};
  document.getElementById('titleShow').checked = !!r.titleShow;
  document.getElementById('titleText').value = r.titleText || '';
  document.getElementById('titleStart').value = r.titleStart || 0;
  document.getElementById('titleEnd').value = r.titleEnd || 4;
  document.getElementById('subtitleShow').checked = !!r.subtitleShow;
  document.getElementById('subtitleText').value = r.subtitleText || '';
  document.getElementById('subtitleStart').value = r.subtitleStart || 0;
  document.getElementById('subtitleEnd').value = r.subtitleEnd || 4;
  document.getElementById('creditsShow').checked = !!r.creditsShow;
  document.getElementById('creditsStart').value = r.creditsStart || 0;
  document.getElementById('creditsEnd').value = r.creditsEnd || 5;
  document.getElementById('creditsTail').value = r.creditsTail || 0;
  document.getElementById('animEnter').value = r.animEnter || 'fade';
  document.getElementById('detFontSize').value = r.detFontSize || 90;
  document.getElementById('detMarginX').value = r.detMarginX || 80;
  document.getElementById('detBlur').value = r.detBlur || 0;
  document.getElementById('detColor').value = r.detColor || '#ffcc00';
  document.getElementById('detAlign').value = r.detAlign || 'center';
  document.getElementById('detVPos').value = r.detVPos || 'bottom';
  document.getElementById('detBorder').checked = !!r.detBorder;
  document.getElementById('detBorderColor').value = r.detBorderColor || '#000000';
}

saveProjectBtn.addEventListener('click', async () => {
  try {
    const result = await window.lyricforge.saveProject(gatherProjectSnapshot());
    if (result.saved) flashTopbarStatus('Project saved.');
  } catch (err) {
    flashTopbarStatus(`Save failed: ${err.message}`, true);
  }
});

loadProjectBtn.addEventListener('click', async () => {
  try {
    const result = await window.lyricforge.loadProject();
    if (!result) return;
    restoreProjectSnapshot(result.data, result.audioExists);
    if (!result.audioExists) {
      flashTopbarStatus('Project loaded, but the original audio file was not found — reattach it in Step 1.', true);
      goToStep('audio');
    } else {
      flashTopbarStatus('Project loaded.');
      goToStep('render');
    }
  } catch (err) {
    flashTopbarStatus(`Load failed: ${err.message}`, true);
  }
});

function flashTopbarStatus(msg, isWarning) {
  // Lightweight inline status — reuses the hint line under whichever
  // step is active by briefly overriding the page title area instead of
  // a modal, so it never blocks interaction.
  const el = document.querySelector('.panel.active h1');
  if (!el) return;
  const original = el.textContent;
  el.textContent = msg;
  el.style.color = isWarning ? 'var(--danger)' : '';
  setTimeout(() => { el.textContent = original; el.style.color = ''; }, 3500);
}

// ---------- STEP 1: AUDIO ----------

const audioDropzone = document.getElementById('audioDropzone');
const audioLabel = document.getElementById('audioLabel');
const audioFileName = document.getElementById('audioFileName');
const audioPlayer = document.getElementById('audioPlayer');
const toLyricsBtn = document.getElementById('toLyrics');

audioDropzone.addEventListener('click', async () => {
  const result = await window.lyricforge.selectAudioFile();
  if (!result) return;
  state.audioPath = result.filePath;
  state.audioFileName = result.fileName;
  audioLabel.textContent = 'Selected:';
  audioFileName.textContent = result.fileName;
  audioPlayer.src = `file://${result.filePath}`;
  audioPlayer.style.display = 'block';
  audioPlayer.addEventListener('loadedmetadata', () => {
    state.audioDuration = audioPlayer.duration;
    updateFillBar();
  });
  toLyricsBtn.disabled = false;
});

toLyricsBtn.addEventListener('click', () => goToStep('lyrics'));

// ---------- STEP 2: LYRICS ----------

const lyricsInput = document.getElementById('lyricsInput');
const toSyncBtn = document.getElementById('toSync');

lyricsInput.addEventListener('input', () => { toSyncBtn.disabled = lyricsInput.value.trim().length === 0; });

toSyncBtn.addEventListener('click', () => {
  const rawLines = lyricsInput.value.split('\n').map((l) => l.trim()).filter((l) => l.length > 0);
  state.lines = [];
  state.words = [];
  rawLines.forEach((lineText, lineIndex) => {
    const lineWords = lineText.split(/\s+/).filter(Boolean);
    const wordObjs = lineWords.map((text) => ({ text, start: null, end: null, lineIndex }));
    state.lines.push({ text: lineText, words: wordObjs });
    state.words.push(...wordObjs);
  });
  state.syncIndex = 0;
  buildSyncLine();
  goToStep('sync');
});

// ---------- STEP 3: SYNC ----------

const syncLine = document.getElementById('syncLine');
const syncPlayPauseBtn = document.getElementById('syncPlayPause');
const syncMarkBtn = document.getElementById('syncMark');
const syncRestartBtn = document.getElementById('syncRestart');
const syncProgressLabel = document.getElementById('syncProgressLabel');
const toClipsBtn = document.getElementById('toClips');

function buildSyncLine() {
  syncLine.innerHTML = '';
  state.words.forEach((w, i) => {
    const span = document.createElement('span');
    span.className = 'word';
    span.textContent = w.text;
    span.dataset.index = i;
    syncLine.appendChild(span);
  });
  updateSyncHighlight();
}

function updateSyncHighlight() {
  const spans = syncLine.querySelectorAll('.word');
  spans.forEach((s, i) => {
    s.classList.remove('current', 'done');
    if (i < state.syncIndex) s.classList.add('done');
    if (i === state.syncIndex) { s.classList.add('current'); s.scrollIntoView({ block: 'nearest', inline: 'center', behavior: 'smooth' }); }
  });
  syncProgressLabel.textContent = `${state.syncIndex} / ${state.words.length} words`;
  toClipsBtn.disabled = state.syncIndex < state.words.length;
}

function markCurrentWord() {
  if (state.syncIndex >= state.words.length) return;
  if (audioPlayer.paused) return;
  const t = audioPlayer.currentTime;
  const w = state.words[state.syncIndex];
  w.start = t;
  if (state.syncIndex > 0 && state.words[state.syncIndex - 1].end == null) state.words[state.syncIndex - 1].end = t;
  state.syncIndex += 1;
  w.end = t + 0.4;
  updateSyncHighlight();
  if (state.syncIndex >= state.words.length) { audioPlayer.pause(); syncPlayPauseBtn.textContent = 'Play'; }
}

function undoLastMark() {
  if (state.syncIndex === 0) return;
  state.syncIndex -= 1;
  const w = state.words[state.syncIndex];
  w.start = null; w.end = null;
  if (state.syncIndex > 0) state.words[state.syncIndex - 1].end = null;
  updateSyncHighlight();
}

function seekBy(deltaSeconds) {
  if (!audioPlayer.duration) return;
  audioPlayer.currentTime = Math.max(0, Math.min(audioPlayer.duration, audioPlayer.currentTime + deltaSeconds));
}

syncPlayPauseBtn.addEventListener('click', () => {
  if (audioPlayer.paused) { audioPlayer.play(); syncPlayPauseBtn.textContent = 'Pause'; }
  else { audioPlayer.pause(); syncPlayPauseBtn.textContent = 'Play'; }
});
syncMarkBtn.addEventListener('click', markCurrentWord);
syncRestartBtn.addEventListener('click', () => {
  state.syncIndex = 0;
  state.words.forEach((w) => { w.start = null; w.end = null; });
  audioPlayer.currentTime = 0;
  audioPlayer.pause();
  syncPlayPauseBtn.textContent = 'Play';
  updateSyncHighlight();
});

document.addEventListener('keydown', (e) => {
  if (state.step !== 'sync') return;
  if (e.code === 'Space') { e.preventDefault(); markCurrentWord(); }
  else if (e.code === 'ArrowRight') { e.preventDefault(); seekBy(5); }
  else if (e.code === 'ArrowLeft') { e.preventDefault(); seekBy(-5); }
  else if (e.code === 'Backspace') { e.preventDefault(); undoLastMark(); }
  else if (e.key.toLowerCase() === 'r') { syncRestartBtn.click(); }
});

toClipsBtn.addEventListener('click', () => goToStep('clips'));

// ---------- STEP 4: CLIPS ----------

const clipQueryInput = document.getElementById('clipQuery');
const clipSearchBtn = document.getElementById('clipSearchBtn');
const clipGrid = document.getElementById('clipGrid');
const toRenderBtn = document.getElementById('toRender');
const fillBar = document.getElementById('fillBar');
const fillLabel = document.getElementById('fillLabel');
const loadMoreBtn = document.getElementById('loadMoreBtn');
const loadMoreStatus = document.getElementById('loadMoreStatus');
const selectedClipList = document.getElementById('selectedClipList');
const selectedCount = document.getElementById('selectedCount');

let currentClipPage = 1;
let currentClipQuery = '';
let clipSearchHasMore = false;

async function runClipSearch() {
  const apiKey = pexelsKeyInput.value.trim();
  const query = clipQueryInput.value.trim();
  if (!apiKey) { alert('Enter your Pexels API key at the top first.'); return; }
  if (!query) return;
  currentClipQuery = query;
  currentClipPage = 1;
  clipGrid.innerHTML = '<div class="dz-sub">Searching...</div>';
  loadMoreBtn.style.display = 'none';
  loadMoreStatus.textContent = '';
  try {
    const result = await window.lyricforge.pexelsSearch({ apiKey, query, perPage: 12, page: 1 });
    state.clips = result.clips;
    clipSearchHasMore = result.hasMore;
    renderClipGrid();
    loadMoreBtn.style.display = clipSearchHasMore ? 'inline-flex' : 'none';
  } catch (err) {
    clipGrid.innerHTML = `<div class="dz-sub">Search failed: ${err.message}</div>`;
  }
}

async function loadMoreClips() {
  const apiKey = pexelsKeyInput.value.trim();
  if (!apiKey || !currentClipQuery) return;
  loadMoreBtn.disabled = true;
  loadMoreBtn.textContent = 'Loading...';
  try {
    currentClipPage += 1;
    const result = await window.lyricforge.pexelsSearch({ apiKey, query: currentClipQuery, perPage: 12, page: currentClipPage });
    state.clips = state.clips.concat(result.clips);
    clipSearchHasMore = result.hasMore;
    renderClipGrid();
    loadMoreBtn.style.display = clipSearchHasMore ? 'inline-flex' : 'none';
    if (!clipSearchHasMore) loadMoreStatus.textContent = 'No more clips for this search.';
  } catch (err) {
    loadMoreStatus.textContent = `Couldn't load more: ${err.message}`;
  } finally {
    loadMoreBtn.disabled = false;
    loadMoreBtn.textContent = 'Load more clips';
  }
}
loadMoreBtn.addEventListener('click', loadMoreClips);

function randomTrim(clipDuration) {
  const sliceLen = Math.min(clipDuration, 5 + Math.random() * 3);
  const maxStart = Math.max(0, clipDuration - sliceLen);
  const trimStart = Math.random() * maxStart;
  return { trimStart, trimDuration: sliceLen };
}

const clipValidation = new Map();

function renderClipGrid() {
  clipGrid.innerHTML = '';
  state.clips.forEach((clip) => {
    const card = document.createElement('div');
    card.className = 'clip-card';
    const selected = state.selectedClips.find((c) => c.id === clip.id);
    if (selected) card.classList.add('selected');
    const validation = clipValidation.get(clip.id);
    if (validation === 'checking') card.classList.add('checking');
    if (validation === 'invalid') card.classList.add('invalid');
    let overlay = '';
    if (validation === 'checking') overlay = `<div class="clip-overlay">Downloading...</div>`;
    else if (validation === 'invalid') overlay = `<div class="clip-overlay bad">Can't load - pick another</div>`;
    card.innerHTML = `
      <img src="${clip.thumbnail}" loading="lazy" />
      <div class="dur">${Math.round(clip.duration)}s</div>
      ${selected ? `<div class="badge">${state.selectedClips.indexOf(selected) + 1}</div>` : ''}
      ${overlay}
    `;
    card.addEventListener('click', () => toggleClipSelection(clip));
    clipGrid.appendChild(card);
  });
}

function renderSelectedClipList() {
  selectedCount.textContent = state.selectedClips.length;
  if (state.selectedClips.length === 0) {
    selectedClipList.innerHTML = '<div class="selected-clip-empty">No clips selected yet.</div>';
    return;
  }
  selectedClipList.innerHTML = state.selectedClips.map((c, i) => `
    <div class="selected-clip-thumb">
      <img src="${c.thumbnail}" loading="lazy" />
      <div class="num">${i + 1}</div>
    </div>
  `).join('');
}

async function toggleClipSelection(clip) {
  const idx = state.selectedClips.findIndex((c) => c.id === clip.id);
  if (idx >= 0) {
    state.selectedClips.splice(idx, 1);
    renderClipGrid(); renderSelectedClipList(); updateFillBar();
    toRenderBtn.disabled = state.selectedClips.length === 0;
    return;
  }
  if (clipValidation.get(clip.id) === 'valid') {
    state.selectedClips.push({ ...clip, ...randomTrim(clip.duration) });
    renderClipGrid(); renderSelectedClipList(); updateFillBar();
    toRenderBtn.disabled = false;
    return;
  }
  if (clipValidation.get(clip.id) === 'checking') return;

  clipValidation.set(clip.id, 'checking');
  renderClipGrid();
  try {
    const result = await window.lyricforge.checkAndCacheClip(clip.downloadUrl, clip.id);
    if (!result.valid) { clipValidation.set(clip.id, 'invalid'); renderClipGrid(); return; }
    clipValidation.set(clip.id, 'valid');
    state.selectedClips.push({ ...clip, ...randomTrim(clip.duration) });
    renderClipGrid(); renderSelectedClipList(); updateFillBar();
    toRenderBtn.disabled = false;
  } catch (err) {
    clipValidation.set(clip.id, 'invalid');
    renderClipGrid();
  }
}

function updateFillBar() {
  const totalSelected = state.selectedClips.reduce((sum, c) => sum + c.trimDuration, 0);
  const songLen = state.audioDuration || 0;
  const pct = songLen > 0 ? Math.min(100, (totalSelected / songLen) * 100) : 0;
  fillBar.style.width = `${pct}%`;
  fillBar.classList.toggle('over', totalSelected >= songLen && songLen > 0);
  fillLabel.textContent = `${totalSelected.toFixed(1)}s selected / ${songLen ? songLen.toFixed(1) : '?'}s song`;
}

clipSearchBtn.addEventListener('click', runClipSearch);
clipQueryInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') runClipSearch(); });
toRenderBtn.addEventListener('click', () => goToStep('render'));

// ---------- STEP 5: RENDER ----------

const renderSummaryEl = document.getElementById('renderSummary');
const renderBtn = document.getElementById('renderBtn');
const renderProgressWrap = document.getElementById('renderProgressWrap');
const renderFill = document.getElementById('renderFill');
const renderProgressLabel = document.getElementById('renderProgressLabel');
const renderSpinner = document.getElementById('renderSpinner');
const fontSelect = document.getElementById('fontSelect');
const lyricModeSeg = document.getElementById('lyricModeSeg');

let selectedLyricMode = 'word';
lyricModeSeg.querySelectorAll('.seg-btn').forEach((btn) => {
  btn.addEventListener('click', () => {
    lyricModeSeg.querySelectorAll('.seg-btn').forEach((b) => b.classList.remove('active'));
    btn.classList.add('active');
    selectedLyricMode = btn.dataset.value;
  });
});

// --- Font select (custom font is a real option in the dropdown) ---

async function loadFontLibrary() {
  state.fontLibrary = await window.lyricforge.getFontLibrary();
  fontSelect.innerHTML = '';
  state.fontLibrary.forEach((f) => {
    const opt = document.createElement('option');
    opt.value = f.id;
    opt.textContent = f.label;
    fontSelect.appendChild(opt);
  });
  const uploadOpt = document.createElement('option');
  uploadOpt.value = '__upload__';
  uploadOpt.textContent = 'Custom font...';
  fontSelect.appendChild(uploadOpt);
}
loadFontLibrary();

function ensureFontOptionExists(value, customFont) {
  if (value === '__customfont__' && customFont) {
    let opt = fontSelect.querySelector('option[value="__customfont__"]');
    if (!opt) {
      opt = document.createElement('option');
      opt.value = '__customfont__';
      fontSelect.insertBefore(opt, fontSelect.querySelector('option[value="__upload__"]'));
    }
    opt.textContent = `Custom: ${customFont.label}`;
  }
}

let lastRealFontValue = fontSelect.value;
fontSelect.addEventListener('change', async () => {
  if (fontSelect.value !== '__upload__') {
    lastRealFontValue = fontSelect.value;
    if (fontSelect.value !== '__customfont__') state.customFont = null;
    return;
  }
  const result = await window.lyricforge.selectCustomFont();
  if (!result) { fontSelect.value = lastRealFontValue; return; }
  state.customFont = result;
  ensureFontOptionExists('__customfont__', result);
  fontSelect.value = '__customfont__';
  lastRealFontValue = '__customfont__';
});

// --- Credits list ---

const creditList = document.getElementById('creditList');
const addCreditBtn = document.getElementById('addCreditBtn');

function renderCreditList() {
  creditList.innerHTML = '';
  state.creditItems.forEach((item, i) => {
    const row = document.createElement('div');
    row.className = 'credit-row';
    const typeOptions = CREDIT_TYPES.map((t) => `<option value="${t}" ${item.type === t ? 'selected' : ''}>${t}</option>`).join('');
    row.innerHTML = `
      <select class="credit-type">${typeOptions}</select>
      ${item.type === 'Custom label' ? `<input type="text" class="credit-label" placeholder="Label" value="${item.customLabel || ''}" style="max-width:110px;" />` : ''}
      <input type="text" class="credit-value" placeholder="Name" value="${item.value || ''}" />
      <button class="remove-btn" title="Remove">&times;</button>
    `;
    row.querySelector('.credit-type').addEventListener('change', (e) => { item.type = e.target.value; renderCreditList(); });
    const labelInput = row.querySelector('.credit-label');
    if (labelInput) labelInput.addEventListener('input', (e) => { item.customLabel = e.target.value; });
    row.querySelector('.credit-value').addEventListener('input', (e) => { item.value = e.target.value; });
    row.querySelector('.remove-btn').addEventListener('click', () => { state.creditItems.splice(i, 1); renderCreditList(); });
    creditList.appendChild(row);
  });
}

addCreditBtn.addEventListener('click', () => {
  state.creditItems.push({ type: 'Producer', value: '' });
  renderCreditList();
});

// --- Position picker (drag + snap) ---

const positionBox = document.getElementById('positionBox');
const positionMarker = document.getElementById('positionMarker');
const snapToggleBtn = document.getElementById('snapToggleBtn');

const SNAP_VALUES = [16.67, 50, 83.33];
function snapValue(v) {
  return SNAP_VALUES.reduce((closest, s) => (Math.abs(v - s) < Math.abs(v - closest) ? s : closest), SNAP_VALUES[0]);
}

function updateMarkerPosition() {
  positionMarker.style.left = `${state.position.xPercent}%`;
  positionMarker.style.top = `${state.position.yPercent}%`;
}
function updateSnapButtonLabel() {
  snapToggleBtn.textContent = `Snapping: ${state.position.snap ? 'On' : 'Off'}`;
}
updateMarkerPosition();
updateSnapButtonLabel();

snapToggleBtn.addEventListener('click', () => {
  state.position.snap = !state.position.snap;
  updateSnapButtonLabel();
});

function setPositionFromEvent(e) {
  const rect = positionBox.getBoundingClientRect();
  let xPercent = ((e.clientX - rect.left) / rect.width) * 100;
  let yPercent = ((e.clientY - rect.top) / rect.height) * 100;
  xPercent = Math.max(2, Math.min(98, xPercent));
  yPercent = Math.max(2, Math.min(98, yPercent));
  if (state.position.snap) { xPercent = snapValue(xPercent); yPercent = snapValue(yPercent); }
  state.position.xPercent = xPercent;
  state.position.yPercent = yPercent;
  updateMarkerPosition();
}

let dragging = false;
positionMarker.addEventListener('mousedown', (e) => { dragging = true; e.preventDefault(); });
positionBox.addEventListener('mousedown', (e) => { if (e.target === positionBox) { dragging = true; setPositionFromEvent(e); } });
document.addEventListener('mousemove', (e) => { if (dragging) setPositionFromEvent(e); });
document.addEventListener('mouseup', () => { dragging = false; });

// --- Summary + gather options ---

function renderSummary() {
  renderSummaryEl.innerHTML = `
    <div><div class="label">Song</div><div class="value">${state.audioFileName || '-'}</div></div>
    <div><div class="label">Words synced</div><div class="value">${state.words.filter((w) => w.start != null).length} / ${state.words.length}</div></div>
    <div><div class="label">Clips selected</div><div class="value">${state.selectedClips.length}</div></div>
    <div><div class="label">Duration</div><div class="value">${state.audioDuration ? Math.round(state.audioDuration) + 's' : '-'}</div></div>
  `;
}

window.lyricforge.onRenderProgress(({ pct, msg }) => {
  renderFill.style.width = `${pct}%`;
  renderProgressLabel.textContent = msg;
});

function gatherRenderOptions() {
  const fontChoice = state.customFont && fontSelect.value === '__customfont__'
    ? { customFamily: state.customFont.family, forceLowercase: false }
    : (() => {
        const libEntry = state.fontLibrary.find((f) => f.id === fontSelect.value);
        return { libraryId: fontSelect.value, forceLowercase: !!(libEntry && libEntry.forceLowercase) };
      })();

  return {
    title: {
      show: document.getElementById('titleShow').checked,
      text: document.getElementById('titleText').value.trim(),
      startTime: parseFloat(document.getElementById('titleStart').value) || 0,
      endTime: parseFloat(document.getElementById('titleEnd').value) || 4,
    },
    subtitle: {
      show: document.getElementById('subtitleShow').checked,
      text: document.getElementById('subtitleText').value.trim(),
      startTime: parseFloat(document.getElementById('subtitleStart').value) || 0,
      endTime: parseFloat(document.getElementById('subtitleEnd').value) || 4,
    },
    credits: {
      show: document.getElementById('creditsShow').checked,
      items: state.creditItems
        .filter((i) => i.value && i.value.trim())
        .map((i) => ({ type: i.type === 'Custom label' ? (i.customLabel || 'Credit') : i.type, value: i.value.trim() })),
      startTime: parseFloat(document.getElementById('creditsStart').value) || 0,
      endTime: parseFloat(document.getElementById('creditsEnd').value) || 5,
      tailSeconds: parseFloat(document.getElementById('creditsTail').value) || 0,
    },
    position: { xPercent: state.position.xPercent, yPercent: state.position.yPercent },
    lyricMode: selectedLyricMode,
    animation: { enter: document.getElementById('animEnter').value },
    font: fontChoice,
    details: {
      fontSize: parseInt(document.getElementById('detFontSize').value, 10) || 90,
      marginX: parseInt(document.getElementById('detMarginX').value, 10) || 80,
      blur: parseFloat(document.getElementById('detBlur').value) || 0,
      color: document.getElementById('detColor').value,
      align: document.getElementById('detAlign').value,
      vposition: document.getElementById('detVPos').value,
      border: document.getElementById('detBorder').checked,
      borderColor: document.getElementById('detBorderColor').value,
    },
  };
}

renderBtn.addEventListener('click', async () => {
  if (!state.audioPath) return alert('No audio loaded.');
  if (state.selectedClips.length === 0) return alert('Select at least one clip.');

  const defaultName = (state.audioFileName || 'lyric-video').replace(/\.[^.]+$/, '') + '.mp4';
  const outputPath = await window.lyricforge.selectOutputPath(defaultName);
  if (!outputPath) return;

  renderBtn.disabled = true;
  renderProgressWrap.style.display = 'block';
  renderSpinner.style.display = 'inline-block';
  renderFill.style.width = '0%';
  renderProgressLabel.textContent = 'Starting...';

  const options = gatherRenderOptions();

  try {
    const result = await window.lyricforge.renderVideo({
      audioPath: state.audioPath,
      words: state.words,
      lines: state.lines,
      clips: state.selectedClips,
      outputPath,
      ...options,
    });
    renderSpinner.style.display = 'none';
    const skippedNote = result.skippedClips > 0
      ? ` (${result.skippedClips} clip${result.skippedClips === 1 ? '' : 's'} skipped due to download issues.)`
      : '';
    renderProgressLabel.textContent = `Done! Saved to ${result.outputPath}${skippedNote}`;
    window.lyricforge.revealInFolder(result.outputPath);
  } catch (err) {
    renderSpinner.style.display = 'none';
    renderProgressLabel.textContent = `Render failed: ${err.message}`;
  } finally {
    renderBtn.disabled = false;
  }
});

// init
renderSelectedClipList();
updateFillBar();
renderCreditList();
goToStep('audio');
